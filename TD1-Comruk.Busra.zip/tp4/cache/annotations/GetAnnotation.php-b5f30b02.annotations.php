<?php

return array(
  '#namespace' => 'Ubiquity\\annotations\\router',
  '#uses' => array (
),
  '#traitMethodOverrides' => array (
  'Ubiquity\\annotations\\router\\GetAnnotation' => 
  array (
  ),
),
);

